double getNumber();
char getOperation();
void displayResult(double result);