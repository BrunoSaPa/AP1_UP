#include "constants.h"

double sum(double a, double b) {
    return a + b;
}

double subtract(double a, double b) {
    return a - b;
}

double calculateCircleArea(double radius) {
    return pi * radius * radius;
}

double calculateRhombusArea(double d1, double d2) {
    return (d1 * d2) / 2;
}