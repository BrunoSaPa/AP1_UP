double sum(double a, double b); 
double subtract(double a, double b);
double calculateCircleArea(double radius);
double calculateRhombusArea(double d1, double d2);